Hello World

```bash
pip3 install jit_ai_hello_world
```

Build the package

```bash
cd jit_ai_hello_world-1.0.0
python3 setup.py sdist bdist_wheel
```

It will generate a .tar.gz and .whl file in the `dist` directory 